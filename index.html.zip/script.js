function checkLove() {
    const response = document.getElementById('response').value.toLowerCase();
    const nameInput = document.getElementById('nameInput');
    const result = document.getElementById('result');

    if (response === 'yes') {
        nameInput.classList.remove('hidden');
        result.textContent = '';
    } else if (response === 'no') {
        result.textContent = 'Thanks.';
        nameInput.classList.add('hidden');
    } else {
        result.textContent = 'Are you pagla?';
        nameInput.classList.add('hidden');
    }
}

function checkName() {
    const name = document.getElementById('name').value.toLowerCase();
    const result = document.getElementById('result');

    if (name === 'kemi') {
        result.textContent = 'what the hell ,Nijer name nijei jigan';
    } else {
        result.textContent = 'I am not interested.';
    }
}
